// ==UserScript==
// @name            AntiX (By xYuri)
// @author          Yuri Akim (xYuri)
// @copyright       Yuri Akim, https://github.com/xYuri.
// @description     Block Porn Sites, Created By xYuri

// @namespace       https://gist.github.com/xYuri

// @run-at          document-body
// @grant           unsafewindow
// @include         *

// @version         1.1.11
// @updateURL       https://gist.github.com/xYuri/8db16a1f53cfd0ed828ae6130e51ec1d/raw/AntiX.user.js
// @downloadURL     https://gist.github.com/xYuri/8db16a1f53cfd0ed828ae6130e51ec1d/raw/AntiX.user.js
//- @require        http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js
// @require         https://gist.github.com/xYuri/12facb7e6a68ac237e62bcc131632f91/raw/AntiX.mainX.js

// @iconURL         https://pastebin.com/cache/img/14/24/24/5415235.jpg
// @icon64URL       https://pastebin.com/cache/img/14/24/24/5415235.jpg
// ==/UserScript==

mainX();