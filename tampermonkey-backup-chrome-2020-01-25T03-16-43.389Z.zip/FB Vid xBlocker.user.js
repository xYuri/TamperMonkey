// ==UserScript==
// @name			FB Vid xBlocker
// @namespace		facebook.com
// @version			0.1
// @description 	Block Facebook Videos, By xYuri
// @author			Yuri Akim
// @match			facebook.com
// @run-at			document-start

// @grant			unsafewindow

// @require			http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js

// @include			*.fb.com/*
// @include			*.facebook.com/*
// ==/UserScript==

//Scripts Start <<<----

var count = 0;

var x = document.createElement("div");
x.id = 'x';
x.className = 'jewelCount _51lp _3z_5 _5ugh';
x.style.cssText = 'position:fixed;z-index:999999;top:5px;left:5px';
x.innerHTML = '0';


function cons(txt){
	console.log(txt + ' >>Count: ' + count);
}

function block(){
	//watch remove
	var watch = document.getElementsByClassName('k4urcfbm');
	if (watch.length > 0){
		count++;
		watch[0].remove();
		cons('Vid Blocked');
	}

	//popup vid
	var popupVid = document.getElementsByClassName('_53j5');
	if(popupVid.length > 0){
		var i3;
		for(i3 = 0; i3 < popupVid.length; i3++){
			count++;
			popupVid[i3].remove();
			cons('Vid Blocked');
		}
	}

	//home vid
	var homeVid = document.getElementsByClassName('_150c');
	if(homeVid.length > 0){
		var i0;
		for(i0 = 0; i0 < homeVid.length; i0++){
			count++;
			homeVid[i0].remove();
			cons('Vid Blocked');
		}
	}

	//live
	var liveVid = document.getElementsByClassName('_7pey');
	if(liveVid.length > 0){
		var i1;
		for(i1 = 0; i1 < liveVid.length; i1++){
			count++;
			liveVid[i1].remove();
			cons('Vid Blocked');
		}
	}

	//group
	var groupVid = document.getElementsByClassName('_2pq7');
	if(groupVid.length > 0){
		var i2;
		for(i2 = 0; i2 < groupVid.length; i2++){
			count++;
			groupVid[i2].remove();
			cons('Vid Blocked');
		}
	}

	x.innerHTML = count;
}


$(document).ready(function(){
	cons("xBlocker Start - By Yuri Akim (xYuri)");
	document.body.appendChild(x);
	setInterval(block, 500);
});


