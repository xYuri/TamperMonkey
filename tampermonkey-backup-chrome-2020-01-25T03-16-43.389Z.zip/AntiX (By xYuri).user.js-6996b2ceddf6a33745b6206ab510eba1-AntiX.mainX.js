//Scripts Start <<<----
var intervalID, bodyLength = 0, body, count, found, breakE = {};
const loadArr = ['--', '\\', '|', '/'];

var x = document.createElement('div');
x.id = 'x';
x.style.cssText = 'position:fixed; z-index:999999; top:0px; left:0px; text-align:center; margin:auto; font-size:99px; background-color:blue; color:red; width:100%; height:100%';
x.innerHTML = '!-!';

function mainX(){
	cons("AntiX Start - Created By Yuri Akim (xYuri)");
	bodyLengthCheck();
	intervalID = setInterval(bodyLengthCheck, 999);
}

const dict = ['porn' ,'sex', 'fuck', 'boobs', 'tits',
	    'breasts', 'bitch', 'whore', 'ass', 'clit',
	    'grope', 'finger', 'hentai', 'anal', 'suck',
	    'creampie', 'squirt', 'blowjob', 'orgasm', 'cum',
	    'pussy'
	   ];

function bodyLengthCheck(){
	var currentBodyLength = document.body.innerHTML.length;
	if(bodyLength != currentBodyLength){
		bodyLength = currentBodyLength;
		contentCheck();
	}
}

function contentCheck(){
	count = 0;
	body = document.body.textContent;
	try{
		dict.forEach((item, i) => {
			found = body.includes(item);
			if(found === true){
				count++;
				cons('Found item#' + i);
				if(count >= 5){
					block();
					throw breakE;
				}
			}
		});
	} catch(e){
		if(e !== breakE) throw e;
	}
}

function block(){
	clearInterval(intervalID);
	document.head.innerHTML = '';
	document.body.innerHTML = '';
	document.body.appendChild(x);
	//load effect
	var i = 0;
	setInterval(()=>{
		x.innerHTML = loadArr[i];
		i++;
		if(i >= 4) i = 0;
	}, 400);
}

function cons(txt){
	console.log(txt + ' >>Count: ' + count);
}
