// ==UserScript==
// @name            xVBlocker (By xYuri)
// @author          Yuri Akim (xYuri)
// @copyright       Yuri Akim.
// @description     Block Facebook Videos, By xYuri

// @run-at          document-idle
// @grant           unsafewindow
// @include         *.fb.com/*
// @include         *.facebook.com/*

// @namespace       https://gist.github.com/xYuri

// @version         1.3.4
// @updateURL       https://gist.github.com/xYuri/da96bd88fb113443c5838e45d409d2c8/raw/xVBlocker.user.js
// @downloadURL     https://gist.github.com/xYuri/da96bd88fb113443c5838e45d409d2c8/raw/xVBlocker.user.js
//- @require        http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js
// @require         https://gist.github.com/xYuri/42dcac99037e2f87e870c7f22b4b63e7/raw/xVBlocker.mainX.js

// @iconURL         https://pastebin.com/cache/img/14/24/24/5415235.jpg
// @icon64URL       https://pastebin.com/cache/img/14/24/24/5415235.jpg
// ==/UserScript==

///$(document).ready(function(){mainX();});

mainX();