// ==UserScript==
// @name            xSitesBlocker (By xYuri)
// @author          Yuri Akim (xYuri)
// @copyright       Yuri Akim, https://github.com/xYuri.
// @description     Block Video Sites, Created By xYuri

// @namespace       https://gist.github.com/xYuri

// @run-at          document-body
// @grant           unsafewindow
// @include         *

// @version         1.2.0
// @updateURL       https://gist.github.com/xYuri/4cf64afcd2ec7ea525784fb96b9a10f2/raw/xSiteBlocker.user.js
// @downloadURL     https://gist.github.com/xYuri/4cf64afcd2ec7ea525784fb96b9a10f2/raw/xSiteBlocker.user.js
//- @require        http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js
// @require         https://gist.github.com/xYuri/30e831f911d806ea90074af5a79f8016/raw/xSiteBlocker.mainX.js

// @iconURL         https://pastebin.com/cache/img/14/24/24/5415235.jpg
// @icon64URL       https://pastebin.com/cache/img/14/24/24/5415235.jpg
// ==/UserScript==

mainX();